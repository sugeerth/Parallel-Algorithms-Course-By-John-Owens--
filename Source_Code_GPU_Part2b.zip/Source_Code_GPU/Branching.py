#!python
import pycuda.driver as cuda
import pycuda.autoinit
from pycuda.compiler import SourceModule
import pycuda.gpuarray as gpuarray
import numpy as np

#Converting the list into numpy array for faster acess and putting it into the GPU for processing... 
start = cuda.Event()
end = cuda.Event()
#Generate random values in the numpy arrays
values = np.random.randn(222341)
#Hardcoding the block size
number_of_blocks=222341/1024
print 'number of blocks', number_of_blocks

#Calculating the (Value-max)/max-min computation and storing it in a numpy array. Pre-calculating the maximum and minimum values.

# Space for the Kernel computation..

#To maximize the FLOPS we essentially increase the computations done per thread, also minimize the amount of memory shared. FLOPS= (Math/Memory) 

# maximise our Math operations in the CUDA Kernel

func_mod = SourceModule("""
// Needed to avoid name mangling so that PyCUDA can
// find the kernel function:
extern "C" {
__global__ void func(float *a,int N,float minval,int denom)
{
int idx = threadIdx.x+threadIdx.y*32+blockIdx.x*blockDim.x;
if (idx < N){
//Ensures that branching is taken every alternate operation

//'% 5' ensures a branch instruction taken 25% of the time

//Although the instructions could be rearraged so that they terminate at warp boundaries, we assume that branch will be taken at every alternate path
if (idx % 20 == 0){
    a[idx] = (a[idx]-minval)/denom;
    a[idx] = a[idx] * a[idx] * 23 * 1000;}
else 
{
   a[idx] = (a[idx]+minval)/denom;
   a[idx] = (a[idx] / a[idx] / 23) * 1000;}
__syncthreads();
}
}

}
""", no_extern_c=1)

func = func_mod.get_function('func')
N = 222341
x = np.asarray(values, np.float32)
x_gpu = gpuarray.to_gpu(x)
h_minval = np.int32(0)
h_denom=np.int32(255)

start.record()
# a function to the GPU to caluculate the computation
# Initiating 1 dimensional 1024 threads in parallel
func(x_gpu.gpudata, np.uint32(N),np.uint32(h_minval),np.uint32(h_denom),block=(1024, 1, 1),grid=(number_of_blocks+1,1,1))
end.record() 
end.synchronize()
secs = start.time_till(end)*1e-3

#We source time the first three results
print "SourceModule time and first three results:"
print "%fs, %s" % (secs, str(x[:3]))

#A function to check if the computation in the CPU is equal to the computation in the GPU 

print 'Func(x):The Value calculated by the GPU ', x_gpu.get()[222341-1],'Actual:  Value calculated in the CPU ',((values[222341-1]-0)/(h_denom))*(values[222341-1]-0)/(h_denom) * 23 * 1000
x_colors=x_gpu.get()
