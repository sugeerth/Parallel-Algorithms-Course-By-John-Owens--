#!python
import pycuda.driver as cuda
import pycuda.autoinit
from pycuda.compiler import SourceModule
import pycuda.gpuarray as gpuarray
import numpy as np

#Converting the list into numpy array for faster acess and putting it into the GPU for processing... 
start = cuda.Event()
end = cuda.Event()
#Generate random values in the numpy arrays
values = np.random.randn(222341)
#Hardcoding the block size
number_of_blocks=222341/1024

#Calculating the (Value-max)/max-min computation and storing it in a numpy array. Pre-calculating the maximum and minimum values.

# Space for the Kernel computation..


# maximise our Math operations in the CUDA Kernel

func_mod = SourceModule("""
// Needed to avoid name mangling so that PyCUDA can
// find the kernel function:
extern "C" {
__global__ void func(float *a,int N,float minval,int denom)
{
int idx = threadIdx.x+threadIdx.y*32+blockIdx.x*blockDim.x;

//Memory coalascing,making sure that idx values are grater than 2 
if ((idx > 2) && (idx % 3))
    a[idx] = (a[idx-1]-minval)/denom;
    a[idx-1] = a[idx-2] * a[idx-1] * 23 * 1000;
    a[idx-2] = a[idx-1] * a[idx-2] * 23 * 1000;
}
}
""", no_extern_c=1)

func = func_mod.get_function('func')
N = 222341
x = np.asarray(values, np.float32)
x_gpu = gpuarray.to_gpu(x)
h_minval = np.int32(0)
h_denom=np.int32(255)

start.record()
# a function to the GPU to caluculate the computation
# Initiating 1 dimensional 1024 threads in parallel
func(x_gpu.gpudata, np.uint32(N),np.uint32(h_minval),np.uint32(h_denom),block=(1024, 1, 1),grid=(number_of_blocks+1,1,1))
end.record() 
end.synchronize()
secs = start.time_till(end)*1e-3

#We source time the first three results
print "SourceModule time and first three results:"

print '\n\n\n\n\n\nTime in seconds',"%fs, \n\n\n\n%s" % (secs, str(x[:3]))

#A function to check if the computation in the CPU is equal to the computation in the GPU 

print 'Func(x):The Value calculated by the GPU ', x_gpu.get()[222341-1]
x_colors=x_gpu.get()
